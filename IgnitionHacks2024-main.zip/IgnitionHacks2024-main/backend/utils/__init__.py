# Import the main utilities from the package for easier access
from .imageProcess import convert_image_to_latex, convert_to_latex
